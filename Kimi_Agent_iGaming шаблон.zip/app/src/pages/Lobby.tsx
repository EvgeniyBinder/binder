import { ArrowDown, ArrowUpRight, Clock3, ShieldCheck, SlidersHorizontal } from 'lucide-react'
import type { Game, GameCategory, Volatility } from '../data'
import type { TranslationKey } from '../i18n'
import { EmptyState, GameCard } from '../components/Common'

interface LobbyProps {
  games: Game[]
  recommended: Game[]
  featured: Game
  favorites: string[]
  onFavorite: (id: string) => void
  onOpen: (game: Game) => void
  onAccount: () => void
  query: string
  setQuery: (value: string) => void
  category: 'all' | GameCategory
  setCategory: (value: 'all' | GameCategory) => void
  provider: string
  setProvider: (value: string) => void
  volatility: 'all' | Volatility
  setVolatility: (value: 'all' | Volatility) => void
  sort: 'name' | 'rtp'
  setSort: (value: 'name' | 'rtp') => void
  providers: string[]
  onClear: () => void
  sessionSeconds: number
  paused: boolean
  t: (key: TranslationKey) => string
}

export default function Lobby(props: LobbyProps) {
  const { games, recommended, featured, favorites, onFavorite, onOpen, onAccount, query, setQuery, category, setCategory, provider, setProvider, volatility, setVolatility, sort, setSort, providers, onClear, sessionSeconds, paused, t } = props
  const time = `${String(Math.floor(sessionSeconds / 3600)).padStart(2, '0')}:${String(Math.floor((sessionSeconds % 3600) / 60)).padStart(2, '0')}:${String(sessionSeconds % 60).padStart(2, '0')}`
  const scrollCatalog = () => document.getElementById('catalog')?.scrollIntoView({ behavior: 'smooth', block: 'start' })

  return (
    <>
      <section className="lobby-hero">
        <div className="hero-copy">
          <span className="eyebrow">{t('heroEyebrow')}</span>
          <h1>{t('heroTitle').split('\n').map((line) => <span key={line}>{line}</span>)}</h1>
          <p>{t('heroText')}</p>
          <div className="hero-actions">
            <button type="button" className="button button-primary" onClick={scrollCatalog}>{t('browse')}<ArrowDown size={18} /></button>
            <button type="button" className="button button-text" onClick={() => onOpen(featured)} disabled={paused}>{t('rules')}<ArrowUpRight size={18} /></button>
          </div>
        </div>
        <button type="button" className="hero-art" onClick={() => onOpen(featured)} disabled={paused} aria-label={`${t('gameInfo')}: ${featured.title}`}>
          <img src={featured.art} alt="" />
          <span className="hero-art-label"><span>{t('featured')}</span><strong>{featured.title}</strong><span>RTP {featured.rtp}%</span></span>
        </button>
      </section>

      <section className="control-strip" aria-label={t('session')}>
        <div className="session-clock"><Clock3 size={20} /><span>{t('session')}<strong>{time}</strong></span></div>
        <div className="session-stat"><span>{t('netResult')}</span><strong className="negative">−$42.50</strong></div>
        <div className="session-limit"><span>35% {t('limitUsed')}</span><div className="limit-track"><span style={{ width: '35%' }} /></div></div>
        <button type="button" className="button button-outline" onClick={onAccount}><ShieldCheck size={18} />{t('myLimits')}</button>
      </section>

      <section className="content-section recommendations">
        <div className="section-heading">
          <div><span className="section-index">01</span><h2>{t('recommended')}</h2></div>
          <p>{t('recommendedText')}</p>
        </div>
        <div className="game-grid recommendation-grid">
          {recommended.map((game) => <GameCard key={game.id} game={game} favorite={favorites.includes(game.id)} onFavorite={() => onFavorite(game.id)} onOpen={() => onOpen(game)} t={t} paused={paused} />)}
        </div>
      </section>

      <section className="content-section" id="catalog">
        <div className="section-heading">
          <div><span className="section-index">02</span><h2>{t('allGames')}</h2></div>
          <p>{t('catalogText')}</p>
        </div>
        <div className="catalog-tools">
          <div className="category-tabs" role="tablist" aria-label={t('allGames')}>
            {(['all', 'slots', 'live', 'table'] as const).map((item) => (
              <button key={item} type="button" role="tab" aria-selected={category === item} className={category === item ? 'selected' : ''} onClick={() => setCategory(item)}>{t(item)}</button>
            ))}
          </div>
          <label className="mobile-search"><span className="sr-only">{t('search')}</span><input value={query} onChange={(e) => setQuery(e.target.value)} placeholder={t('searchHint')} /></label>
          <div className="filter-row">
            <label><span>{t('provider')}</span><select value={provider} onChange={(e) => setProvider(e.target.value)}><option value="all">{t('allProviders')}</option>{providers.map((item) => <option key={item}>{item}</option>)}</select></label>
            <label><span>{t('volatility')}</span><select value={volatility} onChange={(e) => setVolatility(e.target.value as 'all' | Volatility)}><option value="all">{t('allVolatility')}</option><option value="low">{t('low')}</option><option value="medium">{t('medium')}</option><option value="high">{t('high')}</option></select></label>
            <label><span>{t('sort')}</span><select value={sort} onChange={(e) => setSort(e.target.value as 'name' | 'rtp')}><option value="name">{t('byName')}</option><option value="rtp">{t('byRtp')}</option></select></label>
            <button type="button" className="button button-outline clear-button" onClick={onClear}><SlidersHorizontal size={17} />{t('clear')}</button>
          </div>
        </div>
        <div className="results-count"><strong>{games.length}</strong> {t('results')}</div>
        {games.length ? (
          <div className="game-grid catalog-grid">
            {games.map((game) => <GameCard key={game.id} game={game} favorite={favorites.includes(game.id)} onFavorite={() => onFavorite(game.id)} onOpen={() => onOpen(game)} t={t} paused={paused} />)}
          </div>
        ) : <EmptyState title={t('noResults')} text={t('noResultsText')} action={t('clear')} onAction={onClear} />}
      </section>
    </>
  )
}
