# Assets and licenses

- Game artwork and application icons: original procedural artwork created for this project; no third-party game brands or provider logos used.
- Barlow Condensed: Jeremy Tribby and contributors, SIL Open Font License 1.1. Distributed with `public/fonts/barlow-OFL.txt`.
- IBM Plex Sans: IBM and contributors, SIL Open Font License 1.1. Distributed with `public/fonts/ibm-plex-OFL.txt`.
- Interface icons: Lucide, ISC license, installed through the `lucide-react` package.
